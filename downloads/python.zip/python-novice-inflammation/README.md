python-novice-inflammation
==========================

Introduction to Python for non-programmers using inflammation data.

> Please see [https://github.com/swcarpentry/lesson-template](https://github.com/swcarpentry/lesson-template)
> for instructions on formatting, building, and submitting lessons,
> or run `make` in this directory for a list of helpful commands.
