---
layout: page
title: Programming with Python
subtitle: Discussion
---
FIXME: general discussion.
