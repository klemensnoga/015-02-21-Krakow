---
layout: slides
title: Programming with Python
subtitle: Motivation
---
FIXME: why learn Python?
